# 🌱 Potager autonome

Système d'arrosage automatique intelligent basé sur Arduino. Mesure l'humidité du sol et la luminosité pour déclencher automatiquement la pompe à eau selon les besoins de la plante.

## 🎯 Fonctionnalités

- Mesure de l'humidité du sol en temps réel
- Mesure de la luminosité ambiante
- Arrosage automatique si le sol est trop sec
- Arrêt automatique quand le sol est suffisamment humide
- Affichage de l'état sur LCD 16x2
- Logs sur port série pour suivi

## 🛠️ Matériel

| Composant | Rôle |
|-----------|------|
| Arduino Uno | Microcontrôleur principal |
| Capteur humidité sol | Mesure l'humidité du sol |
| Capteur de lumière (LDR) | Mesure la luminosité |
| Pompe à eau + relais | Arrosage automatique |
| LCD 16x2 | Affichage de l'état |

## ⚙️ Branchements

| Composant | Pin Arduino |
|-----------|-------------|
| Capteur humidité | A0 |
| Capteur lumière | A1 |
| Relais pompe | 4 |
| LED indicateur | 5 |
| LCD RS | 7 |
| LCD EN | 8 |
| LCD D4-D7 | 9, 10, 11, 12 |

## 🚀 Lancer le projet

1. Installer la librairie `LiquidCrystal` dans l'Arduino IDE
2. Ouvrir `src/potager_autonome.ino`
3. Téléverser sur Arduino Uno
4. Planter le capteur d'humidité dans le sol

## 📊 Logique d'arrosage

| Humidité mesurée | Action |
|-----------------|--------|
| < 400 (sol sec) | Pompe ON → arrosage |
| 400 – 700 | Surveillance |
| > 700 (sol humide) | Pompe OFF |

## 💡 Ce que j'ai appris

- Lecture de capteurs analogiques et seuillage
- Contrôle d'un relais pour piloter une pompe
- Logique de décision automatisée (if/else sur capteurs)
- Affichage d'informations dynamiques sur LCD
