/*
 * Potager autonome
 * Auteur : Grâce Destinée LEBIKI LAVANYA
 * Description : Système d'arrosage automatique intelligent
 *               Capteur humidité sol + capteur lumière + pompe à eau + LCD
 */

#include <LiquidCrystal.h>

// ===== LCD =====
LiquidCrystal lcd(7, 8, 9, 10, 11, 12);

// ===== PINS =====
#define PIN_HUMIDITE    A0   // Capteur humidité du sol
#define PIN_LUMIERE     A1   // Capteur de lumière (LDR)
#define PIN_POMPE       4    // Relais pompe à eau
#define PIN_LED_POMPE   5    // LED indicateur pompe active

// ===== SEUILS =====
#define SEUIL_HUMIDITE_MIN  400   // En dessous = sol trop sec → arroser
#define SEUIL_HUMIDITE_MAX  700   // Au dessus = sol suffisamment humide
#define SEUIL_LUMIERE_MIN   300   // En dessous = pas assez de lumière
#define DUREE_ARROSAGE      5000  // Durée d'arrosage en ms (5 secondes)
#define INTERVALLE_MESURE   2000  // Mesure toutes les 2 secondes

// ===== VARIABLES =====
int humidite          = 0;
int lumiere           = 0;
bool pompeActive      = false;
unsigned long dernierArrosage  = 0;
unsigned long derniereMesure   = 0;

void setup() {
  pinMode(PIN_POMPE,     OUTPUT);
  pinMode(PIN_LED_POMPE, OUTPUT);
  digitalWrite(PIN_POMPE, LOW);
  digitalWrite(PIN_LED_POMPE, LOW);

  lcd.begin(16, 2);
  Serial.begin(9600);

  lcd.setCursor(0, 0);
  lcd.print("Potager autonome");
  lcd.setCursor(0, 1);
  lcd.print("Demarrage...");
  delay(2000);
  lcd.clear();
}

void loop() {
  unsigned long maintenant = millis();

  // Mesure toutes les 2 secondes
  if (maintenant - derniereMesure >= INTERVALLE_MESURE) {
    derniereMesure = maintenant;

    humidite = analogRead(PIN_HUMIDITE);
    lumiere  = analogRead(PIN_LUMIERE);

    afficherLCD();
    logSerial();

    // Décision d'arrosage
    if (!pompeActive && humidite < SEUIL_HUMIDITE_MIN) {
      demarrerPompe();
    }
  }

  // Arrêt automatique de la pompe après DUREE_ARROSAGE
  if (pompeActive && maintenant - dernierArrosage >= DUREE_ARROSAGE) {
    arreterPompe();
  }

  // Arrêt si sol suffisamment humide
  if (pompeActive && humidite > SEUIL_HUMIDITE_MAX) {
    arreterPompe();
  }
}

// ===== POMPE =====
void demarrerPompe() {
  pompeActive = true;
  dernierArrosage = millis();
  digitalWrite(PIN_POMPE, HIGH);
  digitalWrite(PIN_LED_POMPE, HIGH);
  Serial.println("Arrosage démarré");
}

void arreterPompe() {
  pompeActive = false;
  digitalWrite(PIN_POMPE, LOW);
  digitalWrite(PIN_LED_POMPE, LOW);
  Serial.println("Arrosage arrêté");
}

// ===== AFFICHAGE LCD =====
void afficherLCD() {
  lcd.clear();

  // Ligne 1 : humidité
  lcd.setCursor(0, 0);
  lcd.print("Sol:");
  if (humidite < SEUIL_HUMIDITE_MIN) {
    lcd.print("SEC  ");
  } else if (humidite > SEUIL_HUMIDITE_MAX) {
    lcd.print("HUMIDE");
  } else {
    lcd.print("OK   ");
  }

  // Pompe
  if (pompeActive) {
    lcd.print(" ARROS.");
  }

  // Ligne 2 : lumière
  lcd.setCursor(0, 1);
  lcd.print("Lumiere:");
  if (lumiere < SEUIL_LUMIERE_MIN) {
    lcd.print("FAIBLE");
  } else {
    lcd.print("OK    ");
  }
}

// ===== LOG SÉRIE =====
void logSerial() {
  Serial.print("Humidite: "); Serial.print(humidite);
  Serial.print(" | Lumiere: "); Serial.print(lumiere);
  Serial.print(" | Pompe: "); Serial.println(pompeActive ? "ON" : "OFF");
}
